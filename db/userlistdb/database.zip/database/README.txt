Apache 2.4 
PHP 7.2 - 7.4
MariaDB 10.4
user: root
password: *пароль не задан*